//点击按钮下拉菜单栏
$(function () {
    $(".ct6top #menus").click(function () {
        $(".splay").stop(true, true);//停止动画效果
        $(".splay").slideToggle(500);//二级菜单
    })
})
$(document).scroll(function () {
    var scroH = $(document).scrollTop();  //获得滚动高度
    if (scroH <= 50) {//当高度小于50时
        $(".ct6top").stop();//停止动画效果
        $(".ct6top").animate({ "top": "50px" }, 2, function () {
        })//ct6top设置距离顶部50px
    } else {//否则
        $(".ct6top").stop();
        $(".ct6top").animate({ "top": "0px" }, 5, function () {
        })//ct6top设置距离顶部0px
    }
});
$(function () {
    $(".skinColor>ul li").click(function () {//车皮肤颜色绑定点击效果
        var i = $(this).index();//通过index找到当前span的下标
        $(this).css({"border-bottom":"3px solid #B5A98F"}).siblings().css({"border-bottom":"none"})
        //点击车皮肤，设置下边框，他的兄弟下边框消失
        var v=$(".skinOutPics>ul>li").each(function (index,value) {   
        })//遍历输出车皮肤内容
        var t=$(".skintext p").each(function (index,value) { 
        })  //遍历图片底部文字内容
        $(v[i]).stop();//停止动画效果
        $(v[i]).delay(200).fadeIn(200).siblings().fadeOut(200);
        //点击车皮肤，输出对应皮肤，他的兄弟皮肤消失
        $(t[i]).stop();//停止动画效果
        $(t[i]).delay(200).fadeIn(200).siblings().fadeOut(200);
        //点击车皮肤，输出对应图片底部文字内容，他的兄弟文字消失
    })
})
