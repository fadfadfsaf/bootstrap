//点击按钮下拉菜单栏
$(function(){
    $(".header #menu").click(function(){
        $(".dis").stop(true,true);
        $(".dis").slideToggle(500);
    })
})