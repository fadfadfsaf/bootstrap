

$(function(){
	$("#c").click(function(){
		$("#p2").slideToggle(300);
	})
	$("#s").click(function(){
		$("#p3").slideToggle(300);
	})
	$("#j").click(function(){
		$("#p4").slideToggle(300);
	})
	$("#ct").click(function(){
		$("#p5").slideToggle(300);
	})
	$("#time").click(function(){
		$("#p6").slideToggle(300);
	})
	$("#car").click(function(){
		$("#img1").show();
		$("#w").html("CT6");
	})
	$("#car1").click(function(){
		$("#img1").hide();
		$("#w").html("CT4");
	})
	$("#a").click(function(){
		$("#g").html("购车计划");
	})
	$("#b").click(function(){
		$("#g").html("7天内");
	})
	$("#c").click(function(){
		$("#g").html("15天内");
	})
	$("#d").click(function(){
		$("#g").html("30天内");
	})
	$("#e").click(function(){
		$("#g").html("90天内");
	})
	$("#f").click(function(){
		$("#g").html("短期内暂无购车计划");
	})
//	图片勾选部分
	     var b=1;
   $("#ch1").click(function(){
   	if(b){
   		ch1.src="img/select.jpg";
   		b--;
   	}
   	else{
   		ch1.src="img/select1.jpg";
   		b=1;
   	}
   })
    $("#ch2").click(function(){
   	if(b){
   		ch2.src="img/select.jpg";
   		b--;
   	}
   	else{
   		ch2.src="img/select1.jpg";
   		b=1;
   	}
   })
//  隐藏内容
    $("#in").click(function(){
    	$("#p7").show();
    })
    $("#sure").click(function(){
    	$("#p7").hide();
    })
     $("#sure1").click(function(){
    	$("#p8").hide();
    })
     
//   姓名,手机号,验证提交部分
    $("input[name=username]").keyup(function(){
    	var reg=/^[\u4e00-\u9fa5]{2,4}$/;
    	if(reg.test($(this).val())){
    		$(this).next("span").attr("class","r");
    	}
    	else{
    		$(this).next("span").attr("class","w");
    	}
    })
      $("input[name=pwd]").keyup(function(){
    	var reg=/^(13|17|18|15)\d{9}$/;
    	if(reg.test($(this).val())){
    		$(this).next("span").attr("class","r");
    	}
    	else{
    		$(this).next("span").attr("class","w");
    	}
    })
      $("form[name=form1]").submit(function(){
      	if(!($("input[name=username]").next("span").hasClass("r"))){
      		$("input[name=username]").triggerHandler("keyup");
      		$("#p8").show();
      		return false
      	}
      	if(!($("input[name=pwd]").next("span").hasClass("r"))){
      		$("input[name=pwd]").triggerHandler("keyup");
      		$("#p7").show();
      		return false
      	}
      })
 })

 


